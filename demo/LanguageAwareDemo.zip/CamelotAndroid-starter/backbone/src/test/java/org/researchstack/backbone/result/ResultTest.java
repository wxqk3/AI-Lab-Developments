package org.researchstack.backbone.result;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class ResultTest {

    @Before
    public void setUp() throws Exception {

    }

    @Ignore
    @Test
    public void testResultSerialization() throws Exception {

    }

    @Ignore
    @Test
    public void testResultCopy() throws Exception {

    }

    @Ignore
    @Test
    public void testCollectionResult() throws Exception {

    }
}