package org.researchstack.backbone.step;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class ConsentTest {

    @Before
    public void setUp() throws Exception {

    }

    @Ignore
    @Test
    public void testContentEscaping() throws Exception {

    }

    @Ignore
    @Test
    public void testHtmlForSection() throws Exception {

    }

    @Ignore
    @Test
    public void testSignatureNameRequirements() throws Exception {

    }
}