package org.researchstack.backbone.ui.step.body;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class MultiChoiceQuestionBodyTest {

    @Before
    public void setUp() throws Exception {

    }

    @Ignore
    @Test
    public void testSingleChoice() throws Exception {

    }

    @Ignore
    @Test
    public void testMultiChoice() throws Exception {

    }

    // exclusive not yet implemented on Choice
    @Ignore
    @Test
    public void testSingleChoiceWithOneExclusive() throws Exception {

    }

    @Ignore
    @Test
    public void testSingleChoiceWithTwoExclusives() throws Exception {

    }

    @Ignore
    @Test
    public void testSingleChoiceWithExclusives() throws Exception {

    }

    @Ignore
    @Test
    public void testSingleChoiceWithAllExclusives() throws Exception {

    }

    @Ignore
    @Test
    public void testMultiChoiceWithOneExclusive() throws Exception {

    }

    @Ignore
    @Test
    public void testMultiChoiceWithTwoExclusives() throws Exception {

    }

    @Ignore
    @Test
    public void testMultiChoiceWithExclusives() throws Exception {

    }

    @Ignore
    @Test
    public void testMultiChoiceWithAllExclusives() throws Exception {

    }
}