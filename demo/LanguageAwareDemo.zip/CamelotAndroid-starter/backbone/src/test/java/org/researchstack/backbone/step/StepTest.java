package org.researchstack.backbone.step;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;


public class StepTest {

    @Before
    public void setUp() throws Exception {

    }

    @Ignore
    @Test
    public void testFormStep() throws Exception {

    }

    @Ignore
    @Test
    public void testReactionTimeStep() throws Exception {

    }
}