package org.researchstack.backbone.task;

import org.junit.Ignore;
import org.junit.Test;

/**
 * NavigableOrderedTask is a class in RK that does many of the same things as
 * SmartSurveyTask. In the future it would be nice to implement this to replace SmartSurveyTask.
 */
public class NavigableOrderedTaskTest {
    @Ignore
    @Test
    public void testNavigableOrderedTask() throws Exception {

    }

    @Ignore
    @Test
    public void testNavigableOrderedTaskEmpty() throws Exception {

    }

    @Ignore
    @Test
    public void testNavigableOrderedTaskHeadache() throws Exception {

    }

    @Ignore
    @Test
    public void testNavigableOrderedTaskDizziness() throws Exception {

    }

    @Ignore
    @Test
    public void testNavigableOrderedTaskSevereHeadache() throws Exception {

    }

    @Ignore
    @Test
    public void testNavigableOrderedTaskLightHeadache() throws Exception {

    }

    @Ignore
    @Test
    public void testPredicateStepNavigationRule() throws Exception {

    }

    @Ignore
    @Test
    public void testDirectStepNavigationRule() throws Exception {

    }

    @Ignore
    @Test
    public void testResultPredicates() throws Exception {

    }

}