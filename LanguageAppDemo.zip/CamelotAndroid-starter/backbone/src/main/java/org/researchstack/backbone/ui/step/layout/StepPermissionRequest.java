package org.researchstack.backbone.ui.step.layout;

public interface StepPermissionRequest {
    public void onUpdateForPermissionResult();
}
