package org.researchstack.backbone.ui.callbacks;

public interface SignatureCallbacks {
    void onSignatureStarted();

    void onSignatureCleared();
}
